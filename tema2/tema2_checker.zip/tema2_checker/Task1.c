#include "utils.h"

void SolveTask1() {
    // TODO
}