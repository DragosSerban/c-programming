#include "utils.h"

void SolveTask3() {
    // TODO
}